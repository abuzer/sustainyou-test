export const API_URL = "http://localhost/testsite/wp-json/api/v1/sustainyou"

